These tiles are to be deleted following refactoring and not to be used 

bed_grey2.png
bed_grey2_top_sheet.png
bed_grey.png
bed_white2.png
large_blue.png
large_blue_top_sheet.png
large_peach.png
large_peach_top_sheet.png
large_purple2.png
large_purple2_top_sheet.png
large_purple.png
large_red.png
large_red_top_sheet.png
large_roses.png
large_white2.png
large_white2_top_sheet.png
large_white.png
purple.png
single_roses2.png
single_roses2_top_sheet.png
single_roses.png
single_white2.png
single_white2_top_sheet.png
single_white.png
