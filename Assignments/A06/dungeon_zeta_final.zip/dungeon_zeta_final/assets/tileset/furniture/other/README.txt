The computer image is not to be used in general, it is a special 
image for one place only. It wouldnt' fit the stendhal theme 
(medieval/old fashioned) anywhere else.

